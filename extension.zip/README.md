# chrome-extension

Chrome extention for leveraging text predictions based on machine learning models trained via typelike.me